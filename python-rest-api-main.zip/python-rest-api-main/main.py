from eshop.view.server import run_server

run_server()
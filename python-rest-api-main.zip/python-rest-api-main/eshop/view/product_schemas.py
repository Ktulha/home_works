from marshmallow import Schema,fields


class ProductSchema(Schema):

  id= fields.String()
  name = fields.String(required=True)
  price = fields.Float(required=True)

class ProductGetManyParams(Schema):
  page = fields.Int(required=True)
  limit = fields.Int(required=True)


